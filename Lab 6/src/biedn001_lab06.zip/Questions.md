## Based on your graph, for what array sizes is linear search more efficient than binary search?
    Linear search appears to never be more efficient than binary search. For arrays of size 1, the efficiency is the same, 
    however for every other array size, binary is more efficient.

## Based on your graph, for what array sizes is binary search more efficient than linear search?
    Binary search appears to be the most efficient for every array size. It has the same efficieny for an array of size 1,
    but otherwise binary search is always faster.